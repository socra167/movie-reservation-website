package webtest;

public class Review_write {
	public String title;
	public int mid;
	public String category;
	public String contents;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getMovie() {
		return mid;
	}
	public void setMovie(int mid) {
		this.mid = mid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	
}
